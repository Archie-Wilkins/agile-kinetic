Team 1 - Agile Kinetic Project 

Group Members: 
Ryan Swales - SwalesR@cardiff.ac.uk
Krushang Kumar - VijaykumarK@cardiff.ac.uk
Naeem Ali - AliN20@cardiff.ac.uk
Archie Wilkins - WilkinsAT1@cardiff.ac.uk

Thanks for all your time and feedback :) 

