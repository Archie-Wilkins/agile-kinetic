function open() {
  document.getElementByID("navBar").style.width = "200px";
}

function close() {
  document.getElementByID("navBar").style.width = "0px";
}
